رمضان & منه — Romantic Gift Website

فتح الموقع: افتح index.html في المتصفح.

التاريخ المستخدم: 25/11/2025
الأسماء: رمضان + منه

لإضافة صور حقيقية لاحقاً: يمكن استبدال عناصر photo-placeholder داخل index.html بصور من مجلد assets.

الموقع مصمم Mobile First، ويمكن رفع الملفات كما هي على GitHub/Vercel.
